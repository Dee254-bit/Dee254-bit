"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { FileText, Menu, X } from "lucide-react"
import { cn } from "@/lib/utils"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <FileText className="h-6 w-6 text-primary" />
          <Link href="/" className="text-xl font-bold">
            PDF Master
          </Link>
        </div>

        <nav className="hidden md:flex items-center gap-6">
          <Link href="/tools/ocr" className="text-sm font-medium hover:text-primary">
            OCR
          </Link>
          <Link href="/tools/merge-split" className="text-sm font-medium hover:text-primary">
            Merge & Split
          </Link>
          <Link href="/tools/compress" className="text-sm font-medium hover:text-primary">
            Compress
          </Link>
          <Link href="/tools/edit" className="text-sm font-medium hover:text-primary">
            Edit
          </Link>
          <Link href="/tools/convert" className="text-sm font-medium hover:text-primary">
            Convert
          </Link>
          <Link href="/pricing" className="text-sm font-medium hover:text-primary">
            Pricing
          </Link>
        </nav>

        <div className="hidden md:flex items-center gap-4">
          <Button variant="ghost" asChild>
            <Link href="/login">Log in</Link>
          </Button>
          <Button asChild>
            <Link href="/signup">Sign up</Link>
          </Button>
        </div>

        <Button variant="ghost" size="icon" className="md:hidden" onClick={toggleMenu}>
          {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>

      {/* Mobile menu */}
      <div
        className={cn(
          "fixed inset-x-0 top-16 z-50 bg-background border-b md:hidden transition-all duration-300 ease-in-out",
          isMenuOpen ? "translate-y-0 opacity-100" : "-translate-y-full opacity-0",
        )}
      >
        <div className="container py-4 space-y-4">
          <nav className="flex flex-col space-y-4">
            <Link href="/tools/ocr" className="text-sm font-medium hover:text-primary" onClick={toggleMenu}>
              OCR
            </Link>
            <Link href="/tools/merge-split" className="text-sm font-medium hover:text-primary" onClick={toggleMenu}>
              Merge & Split
            </Link>
            <Link href="/tools/compress" className="text-sm font-medium hover:text-primary" onClick={toggleMenu}>
              Compress
            </Link>
            <Link href="/tools/edit" className="text-sm font-medium hover:text-primary" onClick={toggleMenu}>
              Edit
            </Link>
            <Link href="/tools/convert" className="text-sm font-medium hover:text-primary" onClick={toggleMenu}>
              Convert
            </Link>
            <Link href="/pricing" className="text-sm font-medium hover:text-primary" onClick={toggleMenu}>
              Pricing
            </Link>
          </nav>

          <div className="flex flex-col space-y-2">
            <Button variant="outline" asChild className="w-full">
              <Link href="/login" onClick={toggleMenu}>
                Log in
              </Link>
            </Button>
            <Button asChild className="w-full">
              <Link href="/signup" onClick={toggleMenu}>
                Sign up
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}
